<?php
	//code from parse
	$users_name = $_POST['name'];
	$users_comment = $_POST['comment'];
	if ($users_name&&$users_comment){
	$url = 'https://api.parse.com/1/classes/comments1';  
	 $appId = 'pt6T30MUVMZYwd4gCt77rnULiYsBjXiVB3hruNmJ';  
	 $restKey = 'PCKq3Fpa8Oys089EubYIQHb8N1RQG6ufgXotS3zz';  
	 $headers = array(  
	   "Content-Type: application/json",  
	   "X-Parse-Application-Id: " . $appId,  
	   "X-Parse-REST-API-Key: " . $restKey  
	 );  
	 $objectData = '{"name":"'.$users_name.'","comment":"'.$users_comment.'"}';  
	 $rest = curl_init();  
	 curl_setopt($rest,CURLOPT_URL,$url);  
	 curl_setopt($rest,CURLOPT_POST,1);  
	 curl_setopt($rest,CURLOPT_POSTFIELDS,$objectData);  
	 curl_setopt($rest,CURLOPT_HTTPHEADER,$headers);  
	 curl_setopt($rest,CURLOPT_SSL_VERIFYPEER, false);  
	 curl_setopt($rest,CURLOPT_RETURNTRANSFER, true);  
	 $response = curl_exec($rest);  
	 echo "Submitied";  
	}
?>
<html>
	<head>
		<link rel="apple-touch-icon" sizes="57x57" href="/apple-touch-icon-57x57.png">
		<link rel="apple-touch-icon" sizes="60x60" href="/apple-touch-icon-60x60.png">
		<link rel="apple-touch-icon" sizes="72x72" href="/apple-touch-icon-72x72.png">
		<link rel="apple-touch-icon" sizes="76x76" href="/apple-touch-icon-76x76.png">
		<link rel="apple-touch-icon" sizes="114x114" href="/apple-touch-icon-114x114.png">
		<link rel="apple-touch-icon" sizes="120x120" href="/apple-touch-icon-120x120.png">
		<link rel="apple-touch-icon" sizes="144x144" href="/apple-touch-icon-144x144.png">
		<link rel="apple-touch-icon" sizes="152x152" href="/apple-touch-icon-152x152.png">
		<link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon-180x180.png">
		<link rel="icon" type="image/png" href="/favicon-32x32.png" sizes="32x32">
		<link rel="icon" type="image/png" href="/android-chrome-192x192.png" sizes="192x192">
		<link rel="icon" type="image/png" href="/favicon-96x96.png" sizes="96x96">
		<link rel="icon" type="image/png" href="/favicon-16x16.png" sizes="16x16">
		<link rel="manifest" href="/manifest.json">
		<link rel="mask-icon" href="/safari-pinned-tab.svg" color="#5bbad5">
		<meta name="msapplication-TileColor" content="#da532c">
		<meta name="msapplication-TileImage" content="/mstile-144x144.png">
		<meta name="theme-color" content="#ffffff">
		<!--   -->
		<title>Scottrules44</title>
		<link rel="stylesheet" type="text/css" href="style.css" />
	</head>

	<body>
		<div id= "container">
			<div id = "header">
				<h1>Welcome to Scottrules44!</h2>
			</div>
			<div id = "content">
				<div id= "nav">
					<h3>Navigation</h3>
					<ul>
						<li><a class="buttonLinks" href="https://scottrules44.com/index">Home</a></li>
						<li><a class="buttonLinks" href="https://scottrules44.com/downloads">Downloads</a></li>
						<li><a class="buttonLinks" href="https://scottrules44.com/contact">Contact</a></li>
						<li><a class="buttonLinks"  href="https://docs.scottrules44.com">Docs</a></li>
						<li><a class="buttonLinks" href="https://scottrules44.com/plugins">Plugins</a></li>
					</ul>
				</div>
				<div id = "main">
					<h2>How video games affect our morals?</h2>
					<h4> Rules: </h4>
					<p>--Main Game Only
					<p>--Ranked if the games breaks the following commandments
					<p> 2. You shall not take the name of the LORD your God in vain. (2pt)
					<p> 5. You shall not murder.(2pt)
					<p> 6. You shall not commit adultery. (2pt)
					<p> 7. You shall not steal. (2pt)
					<p> 8. You shall not bear false witness against your neighbor. (2pt)
					<p> 10. You shall not covet your nabors house. (2pt)
					<p> (0 = bad, 2 = great)
					<p>--Each Game will have a score out of 12
					<p>-- 6 and below equals immoral
					<p>-- 5.9 and above is moral
					<p>Note: I am looking at the player not the person in the game.
					<hr>
					<h3>Minecraft</h3>
                    <img src="minecraft.jpg" >
                    <p>
					<p>Minecraft is a creative/survial game avalible for almost any plaforms. It has sold 70 million copies in total.
					<p>I am going to stick to the PC verison of the game for this review.
					<p>
					<p>-- 2rd commandment
					<p>There is no reason to take the lords name in this game and the game does not break this commandment. 1.9 (creepers are the -.1)
					<p>
					<p>-- 5th commandment
					<p>You can murder lots of villages. It is not an objective but it is easy to do.
					<p>Also according Genesis 1:26 humans are the ones who should not be killed animals don't count. 1.5
					<p>
					<p>-- 7th commandment
					<p>There is non here at all. 2.0
					<p>-- 8th commandment
					<p>
					<p>There is lots of steal from other player in this game. It is also common to steal from villages. 1.1
					<p>-- 8th commandment
					<p>
					<p>If you play with another players online or troll you are doing this. 1.3
					<p>
					<p>-- 10th commandment
					<p>This only happens if you play online with friends and not likely to happened if you play by your self. 1.8
					<p>
					<p>-- Conclusion
					<p>It gets a 9.6/12 which means it is moral. Minecraft is just a creative building game for kids and adults to play. It may have a few immoral things like some stealing but the rest it is clean.
					<p>
					<hr>
					<h3>Call Of Duty 4: Modern Warfare</h3>
					<img src="callof.jpg" >
					<p>
					<p>Call of Duty 4: Modern Warfare is the most popular out of all the Call of Duty Games.
					<p>It is a first person shooter where you are tring to take down a country in the middle east. It has sold 15.7 million copies (Nov 2013).
					<p>I am going to stick to the Xbox verison of the game for this review.
					<p>
					<p>-- 2rd commandment
					<p> Here is a bible passage to explain swearing
					<p> Do not let any unwholesome talk come out of your mouths, but only what is helpful for building 
					<p> others up according to their needs, that it may benefit those who listen.  
					<p> And do not grieve the Holy Spirit of God, with whom you were sealed for the day of redemption. (Ephesians 4:29-30)
					<p> Lets start with offline. Offline there is a little bit of swearing, about 3 curse words. 
					<p> Lets go online. There is a lot of swearing. If you google videos of this game online. It is bad.
					<p> There is not much control or any rules on online and is the best place to cyber bully.
					<p> .2
					<p>
					<p>-- 5th commandment
					<p> This is what the game is all about. It is a first person shooter where you kill people.
					<p> 0
					<p>
					<p>-- 6th commandment
					<p> Surprisingly there is non in this game.
					<p> 2
					<p>
					<p>-- 7th commandment
					<p>Let the thief no longer steal, but rather let him labor, doing honest work with his own hands,
					<p>so that he may have something to share with anyone in need.(Ephesians 4:28)
					<p> This ones kind of hard but I cannot count stealing lives that is the 6th commandment
					<p> 1.5
					<p>
					<p>-- 8th commandment
					<p>‘Love your neighbor as yourself.’ (Mark 12:30-31)
					<p> There is lots of trolling and killing of your "neighbor" in this game. That is the main objective of the game.
					<p> 0
					<p>
					<p>-- 10th commandment
					<p> This is like the 7 commandment. 
					<p>You take people lives but that is not the same as stealing material.
					<p> 2
					<p>
					<p>-- Conclusion
					<p> Call of Duty 4 gets a 5.7/12 which means it is Immoral. This game is super blood and violent.
					<p> There is not any stealing or drugs being used at all. If you ever go online There will be lots of swearing.
					<p>
					<hr>
					<h3>Batman: Arkham City</h3>
					<img src="BatmanGame.jpg" >
					<p>Batman: Arkham City is one of the most popular super hero games today. 
					<p>This game is about Batman trying to save people from dying from a disease which the joker gives
					<p>almost everybody (including Batman) and now he must find a cure.
					<p> As of Feb 2012 it has sold 6 Million. This review is about the pc verison.
					<p>
					<p>-- 2rd commandment
					<p>"The lips of the righteous know what is acceptable, 
					<p>but the mouth of the wicked, what is perverse." (Proverbs 10:32)
					<p>There is a lot of swearing in this game. It will make you swearing and there is no online, where people
					<p>swear. There is just alot of swearing in the "main" game. You are going to hear 2 swear words in the first 15 minutes.
					<P>0
					<p>
					<p>-- 5th commandment
					<p>This is pretty hard. Batman does not really kill anyone in this game.
					<p>If you know anything about Batman you know he does not kill anyone.
					<p>You do punch and kick bad guys. This is tough. But you are not killing just husting badly.
					<p>1.2 (you are hurting them so much the people are dead)
					<p>
					<p>-- 6th commandment
					<p>There is no adulty acted on. But, “You have heard that it was said, 
					<p>‘You shall not commit adultery.’ But I tell you that anyone who looks at a woman lustfully has already committed adultery with her in his heart. 
					<p>If your right eye causes you to stumble, gouge it out and throw it away. It is better for you to lose one part of your body than for your 
					<p>whole body to be thrown into hell." (Matthew 5:27-29)
					<p>There is a little bit of this. You can find these part your self.
					<p>1.2
					<p>
					<p>-- 7th commandment
					<p>Batman is rich, he does not steal. Others do in this game, But the player does not.
					<p>2
					<p>
					<p>-- 8th commandment
					<p>You hurt so many people in this game it is insane. You can hear bones cracking.
					<p>Batman may be doing it to help other but you are not.
					<p>0
					<p>
					<p>-- 10th commandment
					<p>Again Batman is rich he doesn't steal from other and neither do you in this game.
					<p>2
					<p>
					<p>-- Conclusion
					<p>Batman: Arkham City gets a 5.9/12 which means it is Immoral. 
					<p>While Batman is a superhero, you are huring people in this game for no reason.
					<p>
					<hr>
					<h3>Grand Theft Auto 5</h3>
					<img src="GTAGame.jpg" style="width:300px;height:199px;" >
					<p>
					<p>GTA V (Grand Theft Auto 5) is a popular open world game released in Nov 2014. There have been 52 million copies sold (May 2015).
					<p>GTA V is 4th most sold game of all time. This review is about the pc verison.
					<p>
					<p>-- 2rd commandment
					<p>Where do I began. The game say f#$# 1018 (<a href="https://games.yahoo.com/blogs/plugged-in/how-many-f-bombs-are-in-gta-v--gamer-counts-the-curses-182152278.html">Source</a>). There is no way to turn this off or down either.
					<p>The chat online is bad with no filtering.
					<p>0 
					<p>
					<p>-- 5th commandment
					<p>Can you kill? This is tricky. You do not absolutely kill players, they wake up in the hospital. But npc (non-playable charaters) are killed.
					<p>You also are trying to kill people in the game. And online you are tring to kill people.
					<p>0
					<p>
					<p>-- 6th commandment
					<p>This is the one of the very few games that have any kind of adultery. There is stripers, prostitute, and sex littered in the game.
					<p>There is even a rape button in the game.
					<p>0
					<p>
					<p>-- 7th commandment
					<p>Stealing is all part of the game. Stealing cars, stealing money, and steal guns.
					<p>When kill people you get money. You can collect money killing people with bounty on there heads.
					<p>0
					<p>
					<p>-- 8th commandment
					<p>You can rape people in the game. You can shoot and kill people in this game. And you can steal cars
					<p>and money from people. So yes you can bare false witness to your nabor.
					<p>0
					<p>
					<p>-- 10th commandment
					<p>“You shall not covet your neighbor’s house." (Exodus 20)
					<p>Can you want other peoples stuff? Yes, if you see a car that you like you can walk right up to it
					<p>and hit the steal car button.
					<p>
					<p>-- Conclusion
					<p>GTA V gets a 0/12 which means it is Immoral. 
					<p>This game is just the worst to play. It is totally immoral. You can commit almost every sin the game.
					<p> 
					<p>
					<hr>
					<h3>The Legend of Zelda: Ocarina of Time</h3>
					<img src="ZeldaGame.jpg" >
					<p>
					<p>The Legend of Zelda: Ocarina of Time is one of the best and most well known games of all time.
					<p>It has sold 11 million units and is the most highest rated game on metacritic. 
					<p>The game is about a hero named link tring to get the triforce (a powerful object) before the Evil Ganondorf does.
					<p>This verison is about the orginal Gamecube verison
					<p>
					<p>-- 2rd commandment
					<p>There is no swearing whats so ever in this game.
					<p>It keeps it clean mouth
					<p>2
					<p>
					<p>-- 5th commandment
					<p>Are you killing people? No. Your are killing evil monsters that are attacking you the player.
					<p>2
					<p>
					<p>-- 6th commandment
					<p>There is nothing sexual really in this game. But people say this.
					<p>"Player will encounter female fairy characters that are dressed suggestively.
					<p>Their skin tight costumes almost seem to be painted on their bodies." (<a href="https://www.commonsensemedia.org/game-reviews/the-legend-of-zelda-ocarina-of-time-3d">Source</a>)\
					<p>1
					<p>
					<p>-- 7th commandment
					<p>"Let the thief no longer steal, but rather let him labor, doing honest work with his own hands, 
					<p> so that he may have something to share with anyone in need."(Ephesians 4:28)
					<p>This is tricky because link is breaking other pots to get rubys and open chest that don't belong to him.
					<p>He is doing this in a magic world but in the real world this is stealing.
					<p>.5
					<p>
					<p>-- 8th commandment
					<p>There is none in this game period
					<p>2
					<p>
					<p>-- 10th commandment
					<p>You are breaking there pots just get rubys insead of working hard and earning them.
					<p>Go cut some grass to get and not break the pots
					<p>.5
					<p>
					<p>-- Conclusion
					<p>The Legend of Zelda: Ocarina of Time gets a 8/12 which means it is moral. 
					<p>While in may do a little stealing, it is not going to theif and is very hard to put down.
					<p>
					<p>
					<form action="index.php", method="POST">
						<table>
						<tr><td>Name: </td><td><input type="text" name = "name"/></td></tr>
						<tr><td colspan="2">Comment: </td></tr>	
						</table>
						<tr><td colspan="2"><textarea name="comment"></textarea></td></tr>
						<tr><td colspan="2"><input type="submit" name = "submit" value="Comment" /></td></tr>	
						</table>
					</form>
				</div>
			</div>

			<div id= "footer">
				<a href="https://www.facebook.com/scott.harrison.52056">
					<img <a class="facebook" src="facebook.png" style="width:40;height:40px" >
				</a>
				<a href="https://www.twitter.com/scottrules44">
					<img <a class="twitter" src="twitter.png" style="width:40px;height:30px;">
				</a>
				<a href="https://www.youtube.com/channel/UCNe1LPJoZTDB4d2JY-UHFvA">
					<img <a class="youtube" src="youtube.png" style="width:40px;height:30px;">
				</a>
				Copyright &copy; 2016 Scott Harrison
			</div>
		</div>
	</body>
</html>